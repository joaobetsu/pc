print("Bem vindo a calculadora normal!")
opcao = input("Escolha uma opção: ")
num1 = float(input("Digite um número: "))
num2 = float(input("Digite outro número: "))

if opcao == "+":
    print(f"O resultado da soma é {num1 + num2}")
elif opcao == "-":
    print(f"O resultado da subtração é {num1 - num2}")
elif opcao == "/":
    print(f"O resultado da divisão é {num1 / num2}")
elif opcao == "*":
    print(f"O resultado da multiplicação é {num1 * num2}")
else:
    print("Opção escolhida inválida! Escolahe entre +, -, /, *.")
# python diretório/nome_arquivo.py -> executar o algoritmo desejado
# ls                               -> listar arquivos e diretórios na pasta
# cd diretório                     -> entrar em algum diretório
# cd..                             -> volta para o diretório anterior
# clear                            -> limpa o terminal
# control + c                      -> mata o algoritmo
# seta pra cima ou pra baixo       -> navega entre comandos anteriores

print("Bem vindo a calculadora de IMC!")

peso = float(input("Digite o seu peso: "))
altura = float(input("Digite a sua altura: "))

imc = peso / (altura ** 2)
print(f"O seu IMC é {imc:.2f}")
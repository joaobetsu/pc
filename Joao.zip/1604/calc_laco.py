print("Bem vindo a calculadora de médias com Laço!")

qtde_notas = int(input("A média de quantas notas você quer calcular: "))

notas = []
for _ in range(0, qtde_notas):
    notas.append(float(input("Digite a sua nota: ")))

soma = 0
for i in notas:
    soma += i
print(f"Sua média é {soma / len(notas)}")
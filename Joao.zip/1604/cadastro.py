import os # importação da biblioteca de sistema operacional
from getpass import getpass

if not os.path.exists("arquivos"): # verifico se o diretório existe
    os.makedirs("arquivos") # se não existir, crio ele

usuarios = [] # criação de lista vazia de usuarios
senhas = [] # criação de lista vazia de senhas
while True:
    print("---------------------------------------------")
    opcao = int(input("Digite 0 para cadastrar e 1 para sair: "))

    if opcao == 1:
        print("Saindo do laço")
        break # quebra o laço
    elif opcao == 0:
        usuarios.append(input("Digite o login: ")) # alimentando lista de usuarios
        senhas.append(getpass("Digite a senha: ")) # alimentando lista de senhas

    else:
        print("Escolha uma opção válida")

    print("---------------------------------------------")

# w -> apaga tudo dentro do arquivo e reescreve
# a -> adicionar ao arquivo sem apagar

    # diretorio do arquivo  # edição 
with open("arquivos/senhas.txt", "a+") as arquivo:
    for indice, usuario in enumerate(usuarios):
        arquivo.write(usuario + " | " + senhas[indice] + "\n")
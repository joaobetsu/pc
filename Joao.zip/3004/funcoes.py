  # nome da função    #paramentos a serem utilizados
def soma_tres_numeros(num1, num2, num3):
    print(num1 + num2 + num3)

def soma_tres_resultado(num1, num2, num3):
    nome = "João" # as variaveis dentro das funções não são enxergadas em outros lugares
    
    return num1 + num2 + num3 # return vai jogar para fora da funçao o resultado e pode ser armazenado em uma variavel
    print("Teste") # abaixo do return nenhum outro código é executado

def par_impar(numero : int):
    return numero % 2 == 0

def cadastro_lista(qtde_valores : int):
    lista = []
    for _ in range(0, qtde_valores):
        lista.append(input("Insira seu valor: "))
    return lista

def calc_imc(qtde : int):
    lista = []
    for _ in range(0, qtde):
        peso = float(input("Digite o seu peso: "))
        alt = float(input("Digite a sua altura: "))
        imc = peso / (alt * alt)
        lista.append(imc)
    return lista

def escreve_arquivo(lista_dados : list, nome_arquivo : str):
    with open(nome_arquivo, "a+") as arquivo:
        for dado_atual in lista_dados:
            arquivo.write(dado_atual + "\n")

def ler_arquivo(nome_arquivo : str):
    with open(nome_arquivo, "r") as arquivo:
        for indice, dado_atual in enumerate(arquivo, 1): # por onde começa o numerador
            print(f"Linha {indice}: {dado_atual}")
        return arquivo, indice # posso retornar varios valroes para fora de funcao
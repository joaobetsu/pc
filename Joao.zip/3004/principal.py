import funcoes # importação do arquivo funcoes.py

# funcao criada soma_tres_numeros

resultado = funcoes.soma_tres_numeros(10, 5, 7)
print(resultado)

# funcao criada par_impar

numero = int(input("Digite um número: "))

if funcoes.par_impar(numero):
    print("Número é par!")
else:
    print("Número é impar!")

# funcao criada cadastro_lista

jogos = funcoes.cadastro_lista(5)
tenis = funcoes.cadastro_lista(int(input("Digite quantos tenis quer cadastrar: ")))
bones = funcoes.cadastro_lista(2)

# funcao criada calc_imc

imc1 = funcoes.calc_imc(int(input("Digite a quantidade de IMC a serem calculados: ")))
print(imc1)

# funcao criada escreve_arquivo

qtde_lista = int(input("Quantos valores você quer cadastrar? "))
resultado_listas = funcoes.cadastro_lista(qtde_lista)
funcoes.escreve_arquivo(resultado_listas, "novo.txt")

# funcao criada le_arquivo

qtde_lista = int(input("Quantos valores você quer cadastrar? "))
resultado_listas = funcoes.cadastro_lista(qtde_lista)
funcoes.escreve_arquivo(resultado_listas, "novo.txt")
funcoes.ler_arquivo("novo.txt")
retorno_arquivo, retorno_indice = funcoes.ler_arquivo("novo.txt")
print(f"O arquivo tem {retorno_arquivo} dados cadastrados")
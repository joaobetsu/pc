import os # importação da lib sistema operacional para ver se o arquivo existe
from getpass import getpass # importação do getpass para esconder a senha

caminho_arquivo = "..arquivo/senhas.txt" # definindo o caminho, .. serve para voltar diretório

if os.path.exists(caminho_arquivo): # verificando se o diretório esta correto
    print("Arquivo existe!") # read = leitura

    usuario_digitado = input("Digite o usuário: ")
    senha_digitado = getpass("Digite a senha: ")
    logado = False

                            # read - modo de leitura
    with open(caminho_arquivo, "r") as arquivo:
        for indice, linha in enumerate(arquivo):
            usuario_arquivo = linha.split(";")[0] # split separa string baseado em um caracter chave
            senha_arquivo = linha.split(";")[1].replace("\n", "") # transformando em lista e depois jogando o indice específico da informação
            if usuario_arquivo == usuario_digitado and senha_arquivo == senha_digitado:
                print("Logado com sucesso!")
                print(f"Seja bem-vindo(a) {usuario_digitado}")
                logado = True

    if not logado: # se a variavel continuar falsa, exibir a mensagem
        print("Usuário ou senha incorreta!")
else:
    print("Diretório errado.")
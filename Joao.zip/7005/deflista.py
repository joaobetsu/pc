def soma(num1, num2 : int):
    print(num1 + num2)
 
def conversor_temperatura(temp : float, conv):
    if conv == "kelvin":
        print(f"{temp + 273}")
    elif conv == "fahrenheit":
        print(f"{(temp * 1.8) + 32}")

def fatorial(numero : float):
    if numero == 0:
        return 1
    else:
        return numero * fatorial(numero -1)

def eh_palindromo(texto : str):
    texto1 = texto.replace(" ", "").lower()
    t = texto1.replace("", ".")
    pal = t.split(".")
    pal.remove(pal[-1])
    pal.remove(pal[-1])
    rever = pal[::-1]
    if pal == rever:
        return True
    else:
        return False
    
def fibonacci(n):
    lista = [0, 1]
    while True:
        proximo = lista[-1] + lista[-2]
        if proximo > n:
            break
        lista.append(proximo)
    return lista if n >= 1 else [0]

def primos_entre(a, b):
    primos = []
    for i in range(a, b + 1):
        if i > 1:
            for x in range(2, int(i **  0.5) + 1):
                if i % x == 0:
                    break
            else:
                primos.append(i)
    return primos

def prefixo_comum(palavras):
    if len(palavras) == 0:
        return ""
    prefixo = palavras[0]
    for i in palavras[1:]:
        while i[:len(prefixo)] != prefixo:
            prefixo = prefixo[:-1]
            if len(prefixo) == 0:
                return ""
    return prefixo